// All editable content for the site: headings, messages, verses and photo paths.
// Edit this file (and add images under assets/) to change the website.
window.SITE_DATA = {
  "texts": {},
  "years": [
    {
      "caps": [
        "Our very first day",
        "Welcome home",
        "Together in 2007"
      ],
      "photos": [
        null,
        null,
        null
      ]
    },
    {
      "caps": [
        "First steps!",
        "Favourite toy",
        "Together in 2008"
      ],
      "photos": [
        "assets/photos/years/2008-1.jpg",
        "assets/photos/years/2008-2.jpg",
        "assets/photos/years/2008-3.jpg"
      ]
    },
    {
      "caps": [
        "Sandbox days",
        "Teddy bear",
        "Together in 2009"
      ],
      "photos": [
        null,
        null,
        null
      ]
    },
    {
      "caps": [
        "Preschool fun",
        "Dress-up time",
        "Together in 2010"
      ],
      "photos": [
        "assets/photos/years/2010-1.jpg",
        "assets/photos/years/2010-2.jpg",
        "assets/photos/years/2010-3.jpg"
      ]
    },
    {
      "caps": [
        "First day of school",
        "New adventures",
        "Together in 2011"
      ],
      "photos": [
        "assets/photos/years/2011-1.jpg",
        "assets/photos/years/2011-2.jpg",
        "assets/photos/years/2011-3.jpg"
      ]
    },
    {
      "caps": [
        "Football in the park",
        "Reading corner",
        "Together in 2012"
      ],
      "photos": [
        "assets/photos/years/2012-1.jpg",
        "assets/photos/years/2012-2.jpg",
        "assets/photos/years/2012-3.jpg"
      ]
    },
    {
      "caps": [
        "",
        "",
        "Together in 2013"
      ],
      "photos": [
        "assets/photos/years/2013-1.jpg",
        "assets/photos/years/2013-2.jpg",
        "assets/photos/years/2013-3.jpg"
      ]
    },
    {
      "caps": [
        "Best friends",
        "Summer holiday",
        "Together in 2014"
      ],
      "photos": [
        null,
        null,
        "assets/photos/years/2014-3.jpg"
      ]
    },
    {
      "caps": [
        "Birthday breakfast",
        "Silly faces",
        "Together in 2015"
      ],
      "photos": [
        "assets/photos/years/2015-1.jpg",
        "assets/photos/years/2015-2.jpg",
        null
      ]
    },
    {
      "caps": [
        "Big trip abroad",
        "Campfire night",
        "Together in 2016"
      ],
      "photos": [
        null,
        null,
        "assets/photos/years/2016-3.jpg"
      ]
    },
    {
      "caps": [
        "Double digits!",
        "New hobby",
        "Together in 2017"
      ],
      "photos": [
        null,
        null,
        "assets/photos/years/2017-3.jpg"
      ]
    },
    {
      "caps": [
        "Secondary school",
        "Side by side",
        "Together in 2018"
      ],
      "photos": [
        null,
        null,
        "assets/photos/years/2018-3.jpg"
      ]
    },
    {
      "caps": [
        "Proud moment",
        "Stage debut",
        "Together in 2019"
      ],
      "photos": [
        "assets/photos/years/2019-1.jpg",
        null,
        null
      ]
    },
    {
      "caps": [
        "Growing up",
        "Road trip",
        "Together in 2020"
      ],
      "photos": [
        "assets/photos/years/2020-1.jpg",
        "assets/photos/years/2020-2.jpg",
        null
      ]
    },
    {
      "caps": [
        "Exams done!",
        "Summer of freedom",
        "Together in 2021"
      ],
      "photos": [
        null,
        null,
        "assets/photos/years/2021-3.jpg"
      ]
    },
    {
      "caps": [
        "New adventures",
        "Quiet moments",
        "Together in 2022"
      ],
      "photos": [
        "assets/photos/years/2022-1.jpg",
        "assets/photos/years/2022-2.jpg",
        null
      ]
    },
    {
      "caps": [
        "Sixth form",
        "Cooking disasters",
        "Together in 2023"
      ],
      "photos": [
        "assets/photos/years/2023-1.jpg",
        "assets/photos/years/2023-2.jpg",
        "assets/photos/years/2023-3.jpg"
      ]
    },
    {
      "caps": [
        "Almost adults",
        "Late nights",
        "Together in 2024"
      ],
      "photos": [
        "assets/photos/years/2024-1.jpg",
        "assets/photos/years/2024-2.jpg",
        "assets/photos/years/2024-3.jpg"
      ]
    },
    {
      "caps": [
        "18th birthday",
        "Ready for the world",
        "Together in 2025"
      ],
      "photos": [
        "assets/photos/years/2025-1.jpg",
        "assets/photos/years/2025-2.jpg",
        "assets/photos/years/2025-3.jpg"
      ]
    }
  ],
  "family": [
    {
      "text": "Happy 19th Birthday to my  darling twins! 🎉🎂🤩🔥\n\n\nTo my beautiful daughter and handsome son,\n\n\nAmazing Duo; Double the joy, double the love, double the blessings! \nWatching you both grow from tiny hands into amazing 19-year-olds has been my greatest gift.\n\n\n*To my daughter* - my diva🥰, my Jesus girl 👧 , my shining star, keep shining, keep dreaming big. You are strong, kind, and beautiful inside and out.\n\n\n*To my son* - my prince, my pride, chibuike…my strength, keep soaring, keep being the amazing young man you are becoming.\n\n\nAs you step into this last year as teenagers, may your path be filled with success, good health, endless laughter, and all your heart desires. May God guide and protect you both always.\n\n\nYou two are my pride, my diva. My rare gem 💎. \nI love you more than words can say.\n\n\nHappy Birthday my twins! Cheers to 19 and to many more glorious years together!\n\n\nLove you loads! ❤️❤️",
      "author": "Mum"
    },
    {
      "text": "The twins of my life, Daniel and Daniella.\nWords alone can not express the joy in my heart when I think of the phenomenal progress you have made from childhood till date.\nI can only thank God and pray for Him to guide, protect and grant you more excellence in life. \nHappy birthday my D and D !\nDaddy loves you. \nEnjoy your day.",
      "author": "Dad"
    },
    {
      "text": "Happy birthday my twins. Keep making me proud and always look out for each other. Love you guys and God bless you❤️🎉",
      "author": "EBUBE "
    },
    {
      "text": "Happy birthday Daniel and Daniella ❤️\nI pray God continues to bless and keep you. I pray He grants you the desires of your heart according to his will. I wish you very best and pray you have the most amazing day.",
      "author": "PRAISE "
    }
  ],
  "daniel": [
    {
      "text": "Happy birthday Daniel, May God Protect U, Dont die✌️and Be strong😂",
      "author": "Ikuru",
      "photo": null
    },
    {
      "text": "🎉🎂 Happy Birthday, Daniel Orlukwu! 🥳❤️\n\n\nBro, where do I even start? 😂❤️ From being classmates back in our Hallel College boarding school days to now being course mates in the university, it's been a journey, and I'm glad we've come this far. We’ve moved from secondary school to university, and the memories keep growing! 🤝🔥\n\n\nOn this special day, I pray that God blesses you with long life, good health, happiness, wisdom, and unlimited success in everything you do. 🙏 May this new chapter of your life bring you closer to your dreams, open greater doors for you, and give you countless reasons to smile.\n\n\nKeep winning, bro! 💯 More life, more blessings, more achievements, and more unforgettable memories ahead. The journey is still long, and the best is yet to come! 🥂🎊\n\n\nHappy Birthday once again, my guy! ❤️🎂🎉\n             From paulinus",
      "author": "PAULINUS ",
      "photo": null
    },
    {
      "text": "Happy birthday Daniel🎂🎉🥳\nMehn where do I start from, you have been a blessing to me, you influenced the way I thought and the way I associate with people. May God continue to bless you and increase you on all sides. Thank you so much for being an amazing friend. I’m blessed to call you a friend.",
      "author": "CHIZURUM ",
      "photo": null
    },
    {
      "text": "Happy birthday Daniel, I wish you good health and success in everything you do and in every area of your life. May this new year bring you peace, growth, and every good thing you've been working for.",
      "author": "ELIJAH ",
      "photo": null
    },
    {
      "text": "Happy birthday, Daniel! 🥳🎉 More life, more blessings, greater achievements, and more wins. May this new year bring you success, happiness, and plenty of reasons to celebrate. Enjoy your day and have a great year ahead! 🥂",
      "author": "best",
      "photo": null
    },
    {
      "text": "🎉 HAPPY 365, DANIEL! , May this new chapter bring you bigger wins, unforgettable adventures, unexpected blessings, and opportunities that take you beyond everything you’ve imagined.\n\n\nWishing you all the very best that life has to offer, cheers to many more birthdays worth celebrating 🙌🏾 🥂\n\n\n~ Daniel Obara ✍🏽",
      "author": "DANIEL OBARA ",
      "photo": null
    },
    {
      "text": "Happy birthday Daniel! I pray that the Lord will continue to keep you and may you see many more years in Jesus name. \n\n\nI will keep selecting you for presentations so don't run away 🤣. \n\n\nHave a lovely day ❤️\n\n\n~ Favour Edubio",
      "author": "FAVOUR ",
      "photo": null
    },
    {
      "text": "More life…",
      "author": "ONUCHUKWU",
      "photo": null
    },
    {
      "text": "Happy birthday to you both! May God bless you with happiness, good health, love, and everything your hearts desire. I pray this new year brings you beautiful memories and countless reasons to smile.\nDaniel, thank you to you for always being there for me, especially during my most difficult moments. Thank you for listening to me and giving me a safe space to pour out my heart whenever I need someone. You may not realize how much it means to me, but I truly appreciate you, and I’m so grateful to have you in my life.\nI love you both and wish you nothing but the very best in life. Keep shining, and enjoy your special day!",
      "author": "PROSPER",
      "photo": null
    },
    {
      "text": "Happy birthday Daniel, May this coming year bring you closer to your dreams, surround you with love, and fill your days with peace and excitement.🎊🎉",
      "author": "HENDRIX",
      "photo": null
    },
    {
      "text": "Happy birthday Daniel🎊🎉\nI wish you many more fruitful years in abundance. I pray that whatever you put into your hands will succeed and your heart desires be granted ❤️🙏 Enjoy your day💕",
      "author": "LAURYNA ",
      "photo": null
    },
    {
      "text": "Happy birthday Daniel, wishing you all the best in this your new age. New achievements and new milestones and many more years. And maybe you'll finally beat me in jump force 😂",
      "author": "EMEKA ",
      "photo": null
    },
    {
      "text": "Happy Birthday, Daniel! 🥳❤️🎂\nMay this new chapter of your life bring you endless happiness, peace, success, and countless beautiful memories. May God continue to guide your steps, bless the works of your hands, and grant you the desires of your heart. I pray that this year brings you closer to everything you’ve ever wished for and opens doors of amazing opportunities for you. You deserve all the good things life has to offer. Keep shining, keep growing in God's wisdom and wealth🥹❤️\nWishing you a beautiful birthday filled with love, laughter, and everything that makes you happy. Cheers to a wonderful new age! 🥂🎉💕",
      "author": "FAVOUR",
      "photo": null
    },
    {
      "text": "It’s always an amazing thing to celebrate people who are worthy of celebration; Today, that person is you. Happy birthday to you, Daniel!\n\n\nIt’s a privilege to go around the year again. A new year brings another opportunity to grow, learn, and make progress.\n\n\nI pray that in this new year, God will meet you at the point of your needs. May every day of this new chapter in your life be filled with joy. I also pray that you’ll continue to grow from strength to strength and experience progress in every aspect of your life.\n\n\nCheers to another year of life. Have a lovely day and a splendid year ahead. 🎉",
      "author": "RICHARD ",
      "photo": null
    },
    {
      "text": "Happy birthday Daniellll!!\nYou're such an amazing person and getting to know you and having you as a course mate has been a pleasure ☺️ \nI pray for more growth and favor in this new age for you and may your star only shine brighter.\nCheers😁",
      "author": "CHIOMA",
      "photo": null
    }
  ],
  "daniella": [
    {
      "text": "Dear Sari,\nI’m grateful for the gift of you in my ;ife, indeed, you have been that friend that sticks closer than a brother 🫂. I cherish the day that our bond began to grow, the conversations we have that always reminds us that we are not alone🥹. Watching you grow and evolve will be something I’ll always be grateful for❤️, so as you celebrate this new year in your life, I pray that Abba lifts and directs your path in this journey of life 🙏.",
      "author": "Lauryna ",
      "photo": "assets/photos/daniella/01-lauryna.jpg"
    },
    {
      "text": "Happy birthday Dannie ( igbo princess) \nYou are who God says you are. One of the wisest and strongest girls I know. I pray the very best for you. You have been such a great blessing to me. 200 level was bearable because of you and Eunice. I don't take you grants. My beautiful star. You are everything to me. Enjoy this lovely day. Love you girlyyyy. More  laughters and joy with you girl. 🫶🏾🫶🏾🫶🏾.",
      "author": "TOLU",
      "photo": "assets/photos/daniella/02-tolu.jpg"
    },
    {
      "text": "Happy birthday Dannyyyy 🌚❤️\n\n\nDanielle, I’m going to write this as a letter to you…\nPaul says to the Philippians, “Every time I think of you, I give thanks to my God.” And this is how I feel towards you—not only because of our friendship, which I so dearly love, but also because of the growth I have seen in you.\nI’m still going to tell you how much I love you, but before that, I want to remind you of your growth and how far you have come, and how much you have allowed the Holy Spirit to work in you.\n\n\nYou have learnt to love.\nAnd I don’t just mean saying “I love you” or being there for people. I mean you have learnt to actually show love. You have become more intentional about the way you care for people, the way you check in, the way you make people feel seen and valued. I have watched you become more expressive with your love, and I think that is such a beautiful thing.\nIf your 200 level self could see you now, I think she would first be shocked 😂 and then probably sit down and realise just how much she has changed. She would be proud of you. She would be grateful for how far you have come. Because the girl you were then is not the woman you are becoming now.\nYou have allowed yourself to be vulnerable. You have learnt that loving people sometimes means letting them see the parts of you that you would rather hide. You have become more open about your feelings, your struggles, your thoughts, and even the things you are still figuring out. And I know that hasn’t always been easy for you.\n\n\nYou have also learnt to let people love you.\nI was actually thinking about this and I was like, “Has she?” 😂 But she has.\nMaybe we’re still working on it—because, girl, there is still work to do 😂( allow me love you moreee😂)but I have seen the growth. You are slowly learning that you don’t always have to be the one giving. You don’t always have to have everything together. You don’t always have to be strong for everyone else.\nYou are learning that it is okay to receive love. It is okay to let people show up for you. It is okay to be cared for without feeling like you have to immediately give something back.\nAnd I think that is one of the things I am most grateful to God for—that I have gotten to witness you become softer .To see you grow in love without losing who you are. To see you become more intentional, more vulnerable, more expressive, and more willing to allow God to work on the areas of your heart that still need His touch.\nAnd honestly, Danielle, I’m so proud of you.\nNot because you have figured everything out—you haven’t, and neither have I 😂but because you keep allowing God to teach you. You keep growing. You keep choosing to become better. And I hope you never become so focused on where you are going that you forget to look back and appreciate how far you have already come.\nAnd I just wanted to be that reminder to\nYou today that your younger self would be so happy to know how far you have come.\n\n\nNow, to some of the reasons why I love love youuu…\n\n\nNow, to some of the reasons why I love love youuu… 🥹❤️\n\n\nI love how you love God so openly and truthfully. Your love for God is so evident, having a friend like you is one of those things that reminds me that God is real and that He is love. I love seeing the way your relationship with Him keeps growing and I love that your faith is not something you hide. You carry it with you and it shows in the way you speak, the way you love, and the way you live.\n\n\nI love how talented you are. Your pen is truly blessed Danielle. I love your spoken words, I love reading your write-ups, and I love listening to you express the things in your heart. There is something so beautiful about the way you put words together to tell us about the love of God and so many other things ( I can still remember hearing you recite “Beauty for ashes “ and how I felt, it was so beautiful and I’m genuinely so glad that we people get to experience that gift\n\n\nI love your personality too. The funny you, the serious you, the dramatic you 👀, I just love you 😂😂\nAnd I love our friendship. I love the memories we have made, the conversations, our jokes ,the way we can say “I have seen you grow from that point to this and I’m proud of you “. I love and I’m grateful that I’m not allowed to be timid around you ,that you call me out when I’m not acting right , so thank you .\nAnd above all, I love who you are becoming and I love watching God work in you❤️\n￼\nSo happy 19th birthday, my love! 🥹❤️\nI pray that this new year you’re beginning brings you so many more blessings, beautiful moments, and reasons to be grateful. I pray that you continue to shine, just as God has called us the light of the world—that every day and in everything you do, your light shines so brightly.\nI pray for the very purpose you were created for, that this year brings you even closer to fulfilling it. May God order your steps, open the right doors for you, bring the right set of people around you and give you the grace and wisdom to walk fully in all that He has prepared for you.\nMay favour always go ahead of you, may grace follow you, and may you never lose sight of who God has called you to be.\nI love you so much, Danielle, and I genuinely can’t wait to see all the ways you continue to shine and all that God does through you. 🤍✨\nHappy 19th, my love! 🥹❤️",
      "author": "EUNICE",
      "photo": "assets/photos/daniella/03-eunice.jpg"
    },
    {
      "text": "Happy birthday Daniella \nHonestly, you’ve been someone who has helped me in shaping how I view friendship. Despite our ups and downs in the very first period of our friendship, we still remained there for each other and I’m so blessed. I’m so grateful to have a friend that doesn’t give up immediately after a rough period. This particular picture describes our friendship in such a funny and unique way. I pray on this day you experience so much joy, peace and love. You are continually strengthened by the Most High and you continually keep walking in the Love of God. Love you my dear half twin🥹❤️",
      "author": "FAITH ",
      "photo": "assets/photos/daniella/04-faith.jpg"
    },
    {
      "text": "My Danie, my girl!! I thank God for your life, and I thank Him for how far He has brought us.\nYour friendship was something that came unexpected, but till date it’s something I cherish with all my heart. \nThe late night conversations, the mystery book reading and writing 😂, the prayers, the fun times - these are memories I can never, ever let go of. \nI pray that our friendship will continue to blossom, stand the test of time, and bring us so much joy and fulfillment. \nI love you soo much, and I’m grateful that God made our paths cross. Cheers to many more amazing years!! ❤️❤️\nHappy birthday girl 🎂🎂🥳",
      "author": "IJEOMA ",
      "photo": "assets/photos/daniella/05-ijeoma.jpg"
    },
    {
      "text": "Dani darling. \nQueeeeennn \n \nHappy birthdaaaayyy 🥳🥳❤️\nGetting close to you these past few months have been amazing cuz you’re amazing. I pray that the Lord will continue to bless you. I pray that your path is as the path of the just that shines brighter and brighter unto the perfect day. I pray that all the days of your life you will dwell in the house of the Lord and may you always be surrounded by people who love you genuinely (a.k.a Me). In Jesus name. Amen! \n\n\nI love you Queeeeenn ❤️❤️",
      "author": "SALAMA",
      "photo": "assets/photos/daniella/06-salama.jpg"
    },
    {
      "text": "My sweet Daniella,\n\n\nMy friend turned sister, where do I even start? 🥹❤️\n\n\nI’m so grateful to God for the blessing of you, and I’m equally grateful to you for being such a beautiful part of my life. Because of you, I know what it means to love and be loved. I know what it means to have someone who is genuinely there for me, someone who always has my best interests at heart and wants nothing but the best for me.\n\n\nThank you for always being just a call away. Thank you for showing up for me, for listening to me, for supporting me, and for loving me in ways that remind me how blessed I am to have you. I’m so happy when I think about all the battles we’ve fought together and conquered. We’ve laughed together, cried together, prayed together, and prayed for each other, and every time I think about it, I’m filled with so much love and gratitude for you.\n\n\nI love everything about you. I love your laugh, your smile, your beauty, your heart, your dedication to God, and your passion for the things of God.I love how honest you are, how i can come to you and you always meet me with love and grace and never judgement. I love the person you are, and I love that I get to witness the beautiful person you continue to become. There’s something so special about having a friend who feels like home, and that’s exactly what you are to me.\n\n\nThank you for always sitting with me in my emotions, even when none of them made sense to me. Thank you for being patient with me, for holding space for me, and for never making me feel like I have to figure everything out on my own. Thank you for always seeing something in me that I still struggle to see in myself till today. Thank you for believing in me, even in moments when I find it difficult to believe in myself, and for constantly pushing me to become a better person. You have no idea how much that means to me.\n\n\nSometimes, I think about how beautiful it is that God allowed our paths to cross and gave me someone like you. Out of all the people I could have met in this life, He gave me you, and I will never take that for granted. You have been such a gift to me, and I pray that I never become so familiar with your presence that I forget just how much of a blessing you are.\n\n\nMy prayer for you is that God loves on you in the same beautiful ways you have loved on me. May He answer the prayers you whisper when nobody else is listening, strengthen you in the moments when you feel weak, and remind you of how deeply loved you are, especially on the days when life feels overwhelming. May you never lack genuine love, peace, joy, or people who show up for you the way you have always shown up for me. May you continue to grow in your walk with God, and may your life always be a beautiful reflection of His goodness.\n\n\nI hope you know that this love goes both ways. Just as you have been there for me, I want to be there for you, through every season, every battle, every win, and every moment in between. I want to celebrate you loudly, pray for you faithfully, hold your hand when things get difficult, and remind you of who you are when you forget.\n\n\nYou are so much more than a friend to me, Daniella. You are my sister, my safe place, one of my answered prayers, and one of the many ways God has reminded me that His love can be experienced through people. And if there is one thing I hope you never doubt, it is how much you mean to me.\n\n\nThank you for being you. Thank you for being my person. Thank you for all the beautiful memories we’ve made and for all the ones we are yet to make. I look forward to growing with you, doing life with you, and watching God do amazing things in and through you.\n\n\nI love you so, so much, my sweet Daniella. More than these words can ever fully explain. And if I had to do life all over again, I would still pray for a friendship like ours, and I would still choose you every single time. I’m excited to see how far we go together especially now we’re roomates ❤️🥹",
      "author": "miebaka",
      "photo": "assets/photos/daniella/07-miebaka.jpg"
    },
    {
      "text": "Happy Birthday Sari Koko🙊🙉🙈🐒🔥🔥🔥🔥❤️‍🔥❤️‍🔥❤️‍🔥❤️‍🔥\n\n\nYou're such an amazing person🔥\n\n\nI really thank God for you! Thank you for being so intentional and caring. \n\n\n(I would have said I love you, buh you know, we gangsters🤣😎)\n\n\nI love you so much!❤️‍🔥❤️‍🔥",
      "author": "tochi",
      "photo": "assets/photos/daniella/08-tochi.jpg"
    },
    {
      "text": "Happy birthday Smallie I thank God for everything he has been doing in your life and what he has been using you to do. I pray for more Grace, Favour and blessings in your life. Thank you for always being there for me even when I don’t know how to talk about things. I didn’t think it was necessary to have more close friends especially this final year but of course you love to prove me wrong 😭😭😭 and you did. I thank God for placing you in my life 🙏 Love you so much .",
      "author": "AJURII",
      "photo": "assets/photos/daniella/09-ajurii.jpg"
    },
    {
      "text": "Happy Birthday my beautiful Daniella . I wish you long life and prosperity. Wishing you good health and happiness as you turn this new age.\nI have known you for 8years now😂❤️\nI remember when I use to wash your clothes that year. Iron your cloths , even wash your plates 😭 because I cared about you. And I’m glad we still crossed path even after secondary school.\nThank you for being an amazing friend and listening ear to me.  Thank you so much for your love and care ❤️\nI pray that your heart desires are fulfilled ✨🙏🏾\nI love you\nFrom your daughter Humaira!❣️",
      "author": "HUMAIRA",
      "photo": "assets/photos/daniella/10-humaira.jpg"
    },
    {
      "text": "Happy birthday Daniella, may the Lord continue to bless you, keep you and favor you in Jesus name. I pray that you will be happy and that the Lord will continue to put a smile on your face in Jesus ☺️",
      "author": "KILSI",
      "photo": "assets/photos/daniella/11-kilsi.jpg"
    },
    {
      "text": "The day has finally comee💃💃💃 Happy birthdayyyyy Deeeee. I know we just started becoming close just but it feels like we’ve been friends for the longest time. I have always admired you as a person but I was always too shy to talk to you but here we are talking like never before. I know we just started being close but I want to let you know that I value what we have so much and I hope and pray that we would become friends forever. I want to wish you a happy happy birthday and I pray that this would be your best year yet, you would experience God’s love like never before. I pray for God’s favour and mercy upon your life, you will grow in wisdom and you will excel in everything you do. I love you soo much, happy a lovely day my girllll❤️❤️",
      "author": "NICOLE",
      "photo": "assets/photos/daniella/12-nicole.jpg"
    },
    {
      "text": "Happy birthday my Dani girl🥹,\nohh my little baby is growing 😂 i’m extremely glad i met you in 100 level and forced you to be my friend 😂you have literally seen me at my worse and never judged me , for that i will always love and appreciate you ❤️you’re an amazing person and very talented. i pray you continue to shine and that God gives you clarity and peace this new year💗\ni will always be here for you and always love you even though you can be annoying sometimes 😂 \ni love you baby girl, i always will 🤍.",
      "author": "JOY",
      "photo": "assets/photos/daniella/13-joy.jpg"
    },
    {
      "text": "Daniellaaa🥹🥹🥹\nDee Boo, as I’d always call you🌚🥹\nHappy birthday to you my darling girl 🥳🤩\nMy prophetess!!🌚🌚\nI’m so glad to have watched you grow and evolve into the beautiful woman you are today😍❤️\nDaniella you’re special and anyone that knows you knows that🌚❤️\nI’m grateful to be part of your story, for the privilege to know you, grow with you, learn from you, laugh with you and even cry with you😭😭🥹\nI have seen you metamorphose into the strong girl you are today with Gods help of course🤎🤍🤎\nI really admire your relationship with God and your heart for His work and I know He is taking you to places unimaginable 🥹🩷🙏\nThis new year, I pray for Favour all round💜✝️\nI pray for greater clarity🙏🩷\nI pray for Grace to walk in alignment, Grace to obey, Grace to follow🙏💛\nI pray for sound health, long life, discernment, prosperity, godly friends 🙇‍♀️🙇‍♀️🙏\nI pray for a greater and a more beautiful dimension of your relationship with God🥹🙏\nI pray that through you, many shall come to Jesus🙏🤍\nThere will be great joy in heaven on your account in Jesus name 🙏\nI love you so much girl❤️❤️\nI wish you long life and prosperity 🥳🥳\nYou deserve the best🥰😍😘",
      "author": "UKEME",
      "photo": "assets/photos/daniella/14-ukeme.jpg"
    },
    {
      "text": "Happy birthday Daniella!\n\n\nWho would’ve guessed that we would ever gather to celebrate someone from Ikwere of all places. I can neither confirm nor deny whether or not I consider you a citizen, but I do know that I’m incredibly grateful to be your friend. I think that you are a wonderful, beautiful, sunny person and I love that who you are consistently shines through even when you’re struggling. I think that in that way you are inspiring. It has been a privilege to have my life brightened by your smile. I love you very much, and it totally doesn’t matter at all where you’re from! I pray that you have an amazing birthday and that you’re able to perceive how loved and cherished you are by the people around you, how thankful we are to have you around. I pray that you continue to be awesome and wonderful and that you’re blessed with every good thing this world has to offer. Happy birthday again!",
      "author": "SAMUEL ",
      "photo": "assets/photos/daniella/15-samuel.jpg"
    }
  ],
  "playlistImg": "assets/playlist-cover.jpg",
  "verses": [
    {
      "id": "identity",
      "title": "Identity",
      "blurb": "Who you are in His eyes",
      "items": [
        {
          "t": "I will praise thee; for I am fearfully and wonderfully made: marvellous are thy works; and that my soul knoweth right well.",
          "r": "Psalm 139:14",
          "v": "KJV"
        },
        {
          "t": "But now thus saith the LORD that created thee, O Jacob, and he that formed thee, O Israel, Fear not: for I have redeemed thee, I have called thee by thy name; thou art mine.",
          "r": "Isaiah 43:1",
          "v": "KJV"
        },
        {
          "t": "Therefore if any man be in Christ, he is a new creature: old things are passed away; behold, all things are become new.",
          "r": "2 Corinthians 5:17",
          "v": "KJV"
        },
        {
          "t": "But ye are a chosen generation, a royal priesthood, an holy nation, a peculiar people; that ye should shew forth the praises of him who hath called you out of darkness into his marvellous light.",
          "r": "1 Peter 2:9",
          "v": "KJV"
        },
        {
          "t": "But as many as received him, to them gave he power to become the sons of God, even to them that believe on his name.",
          "r": "John 1:12",
          "v": "KJV"
        },
        {
          "t": "I am crucified with Christ: nevertheless I live; yet not I, but Christ liveth in me: and the life which I now live in the flesh I live by the faith of the Son of God, who loved me, and gave himself for me.",
          "r": "Galatians 2:20",
          "v": "KJV"
        },
        {
          "t": "For ye have not received the spirit of bondage again to fear; but ye have received the Spirit of adoption, whereby we cry, Abba, Father. The Spirit itself beareth witness with our spirit, that we are the children of God.",
          "r": "Romans 8:15-16",
          "v": "KJV"
        },
        {
          "t": "Behold, what manner of love the Father hath bestowed upon us, that we should be called the sons of God: therefore the world knoweth us not, because it knew him not.",
          "r": "1 John 3:1",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "beauty",
      "title": "Beauty",
      "blurb": "Fair, honoured and wonderfully made",
      "items": [
        {
          "t": "Behold, thou art fair, my love; behold, thou art fair; thou hast doves' eyes.",
          "r": "Song of Solomon 1:15",
          "v": "KJV"
        },
        {
          "t": "Thou art all fair, my love; there is no spot in thee.",
          "r": "Song of Solomon 4:7",
          "v": "KJV"
        },
        {
          "t": "My beloved spake, and said unto me, Rise up, my love, my fair one, and come away.",
          "r": "Song of Solomon 2:10",
          "v": "KJV"
        },
        {
          "t": "Who is she that looketh forth as the morning, fair as the moon, clear as the sun, and terrible as an army with banners?",
          "r": "Song of Solomon 6:10",
          "v": "KJV"
        },
        {
          "t": "So shall the king greatly desire thy beauty: for he is thy Lord; and worship thou him.",
          "r": "Psalm 45:11",
          "v": "KJV"
        },
        {
          "t": "For the LORD taketh pleasure in his people: he will beautify the meek with salvation.",
          "r": "Psalm 149:4",
          "v": "KJV"
        },
        {
          "t": "He hath made every thing beautiful in his time.",
          "r": "Ecclesiastes 3:11",
          "v": "KJV"
        },
        {
          "t": "For we are his workmanship, created in Christ Jesus unto good works, which God hath before ordained that we should walk in them.",
          "r": "Ephesians 2:10",
          "v": "KJV"
        },
        {
          "t": "Who can find a virtuous woman? for her price is far above rubies.",
          "r": "Proverbs 31:10",
          "v": "KJV"
        },
        {
          "t": "Strength and honour are her clothing; and she shall rejoice in time to come.",
          "r": "Proverbs 31:25",
          "v": "KJV"
        },
        {
          "t": "She openeth her mouth with wisdom; and in her tongue is the law of kindness.",
          "r": "Proverbs 31:26",
          "v": "KJV"
        },
        {
          "t": "Many daughters have done virtuously, but thou excellest them all.",
          "r": "Proverbs 31:29",
          "v": "KJV"
        },
        {
          "t": "Thou shalt also be a crown of glory in the hand of the LORD, and a royal diadem in the hand of thy God.",
          "r": "Isaiah 62:3",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "anxiety",
      "title": "Anxiety",
      "blurb": "Hand it all over to Him",
      "items": [
        {
          "t": "Be careful for nothing; but in every thing by prayer and supplication with thanksgiving let your requests be made known unto God. And the peace of God, which passeth all understanding, shall keep your hearts and minds through Christ Jesus.",
          "r": "Philippians 4:6-7",
          "v": "KJV"
        },
        {
          "t": "Casting all your care upon him; for he careth for you.",
          "r": "1 Peter 5:7",
          "v": "KJV"
        },
        {
          "t": "Take therefore no thought for the morrow: for the morrow shall take thought for the things of itself. Sufficient unto the day is the evil thereof.",
          "r": "Matthew 6:34",
          "v": "KJV"
        },
        {
          "t": "In the multitude of my thoughts within me thy comforts delight my soul.",
          "r": "Psalm 94:19",
          "v": "KJV"
        },
        {
          "t": "Cast thy burden upon the LORD, and he shall sustain thee: he shall never suffer the righteous to be moved.",
          "r": "Psalm 55:22",
          "v": "KJV"
        },
        {
          "t": "Come unto me, all ye that labour and are heavy laden, and I will give you rest.",
          "r": "Matthew 11:28",
          "v": "KJV"
        },
        {
          "t": "Trust in the LORD with all thine heart; and lean not unto thine own understanding. In all thy ways acknowledge him, and he shall direct thy paths.",
          "r": "Proverbs 3:5-6",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "depression",
      "title": "Depression",
      "blurb": "He is close to the brokenhearted",
      "items": [
        {
          "t": "The LORD is nigh unto them that are of a broken heart; and saveth such as be of a contrite spirit.",
          "r": "Psalm 34:18",
          "v": "KJV"
        },
        {
          "t": "Why art thou cast down, O my soul? and why art thou disquieted within me? hope thou in God: for I shall yet praise him, who is the health of my countenance, and my God.",
          "r": "Psalm 42:11",
          "v": "KJV"
        },
        {
          "t": "Weeping may endure for a night, but joy cometh in the morning.",
          "r": "Psalm 30:5",
          "v": "KJV"
        },
        {
          "t": "I waited patiently for the LORD; and he inclined unto me, and heard my cry. He brought me up also out of an horrible pit, out of the miry clay, and set my feet upon a rock, and established my goings.",
          "r": "Psalm 40:1-2",
          "v": "KJV"
        },
        {
          "t": "When thou passest through the waters, I will be with thee; and through the rivers, they shall not overflow thee: when thou walkest through the fire, thou shalt not be burned; neither shall the flame kindle upon thee.",
          "r": "Isaiah 43:2",
          "v": "KJV"
        },
        {
          "t": "They that sow in tears shall reap in joy.",
          "r": "Psalm 126:5",
          "v": "KJV"
        },
        {
          "t": "And the LORD, he it is that doth go before thee; he will be with thee, he will not fail thee, neither forsake thee: fear not, neither be dismayed.",
          "r": "Deuteronomy 31:8",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "hope",
      "title": "Hope",
      "blurb": "Brighter days are coming",
      "items": [
        {
          "t": "For I know the thoughts that I think toward you, saith the LORD, thoughts of peace, and not of evil, to give you an expected end.",
          "r": "Jeremiah 29:11",
          "v": "KJV"
        },
        {
          "t": "Now the God of hope fill you with all joy and peace in believing, that ye may abound in hope, through the power of the Holy Ghost.",
          "r": "Romans 15:13",
          "v": "KJV"
        },
        {
          "t": "It is of the LORD's mercies that we are not consumed, because his compassions fail not. They are new every morning: great is thy faithfulness.",
          "r": "Lamentations 3:22-23",
          "v": "KJV"
        },
        {
          "t": "Be of good courage, and he shall strengthen your heart, all ye that hope in the LORD.",
          "r": "Psalm 31:24",
          "v": "KJV"
        },
        {
          "t": "But they that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.",
          "r": "Isaiah 40:31",
          "v": "KJV"
        },
        {
          "t": "And we know that all things work together for good to them that love God, to them who are the called according to his purpose.",
          "r": "Romans 8:28",
          "v": "KJV"
        },
        {
          "t": "Now faith is the substance of things hoped for, the evidence of things not seen.",
          "r": "Hebrews 11:1",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "love",
      "title": "Love",
      "blurb": "Loved without limit",
      "items": [
        {
          "t": "Yea, I have loved thee with an everlasting love: therefore with lovingkindness have I drawn thee.",
          "r": "Jeremiah 31:3",
          "v": "KJV"
        },
        {
          "t": "The LORD thy God in the midst of thee is mighty; he will save, he will rejoice over thee with joy; he will rest in his love, he will joy over thee with singing.",
          "r": "Zephaniah 3:17",
          "v": "KJV"
        },
        {
          "t": "For I am persuaded, that neither death, nor life, nor angels, nor principalities, nor powers, nor things present, nor things to come, nor height, nor depth, nor any other creature, shall be able to separate us from the love of God, which is in Christ Jesus our Lord.",
          "r": "Romans 8:38-39",
          "v": "KJV"
        },
        {
          "t": "We love him, because he first loved us.",
          "r": "1 John 4:19",
          "v": "KJV"
        },
        {
          "t": "For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.",
          "r": "John 3:16",
          "v": "KJV"
        },
        {
          "t": "Charity suffereth long, and is kind; charity envieth not; charity vaunteth not itself, is not puffed up, doth not behave itself unseemly, seeketh not her own, is not easily provoked, thinketh no evil; rejoiceth not in iniquity, but rejoiceth in the truth; beareth all things, believeth all things, hopeth all things, endureth all things.",
          "r": "1 Corinthians 13:4-7",
          "v": "KJV"
        },
        {
          "t": "There is no fear in love; but perfect love casteth out fear: because fear hath torment. He that feareth is not made perfect in love.",
          "r": "1 John 4:18",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "healing",
      "title": "Healing",
      "blurb": "Restored, mended, made whole",
      "items": [
        {
          "t": "He healeth the broken in heart, and bindeth up their wounds.",
          "r": "Psalm 147:3",
          "v": "KJV"
        },
        {
          "t": "For I will restore health unto thee, and I will heal thee of thy wounds, saith the LORD.",
          "r": "Jeremiah 30:17",
          "v": "KJV"
        },
        {
          "t": "Beloved, I wish above all things that thou mayest prosper and be in health, even as thy soul prospereth.",
          "r": "3 John 1:2",
          "v": "KJV"
        },
        {
          "t": "Heal me, O LORD, and I shall be healed; save me, and I shall be saved: for thou art my praise.",
          "r": "Jeremiah 17:14",
          "v": "KJV"
        },
        {
          "t": "But he was wounded for our transgressions, he was bruised for our iniquities: the chastisement of our peace was upon him; and with his stripes we are healed.",
          "r": "Isaiah 53:5",
          "v": "KJV"
        },
        {
          "t": "He sent his word, and healed them, and delivered them from their destructions.",
          "r": "Psalm 107:20",
          "v": "KJV"
        },
        {
          "t": "But unto you that fear my name shall the Sun of righteousness arise with healing in his wings.",
          "r": "Malachi 4:2",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "peace",
      "title": "Peace",
      "blurb": "Rest in Him",
      "items": [
        {
          "t": "Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.",
          "r": "John 14:27",
          "v": "KJV"
        },
        {
          "t": "Thou wilt keep him in perfect peace, whose mind is stayed on thee: because he trusteth in thee.",
          "r": "Isaiah 26:3",
          "v": "KJV"
        },
        {
          "t": "The LORD bless thee, and keep thee: the LORD make his face shine upon thee, and be gracious unto thee: the LORD lift up his countenance upon thee, and give thee peace.",
          "r": "Numbers 6:24-26",
          "v": "KJV"
        },
        {
          "t": "I will both lay me down in peace, and sleep: for thou, LORD, only makest me dwell in safety.",
          "r": "Psalm 4:8",
          "v": "KJV"
        },
        {
          "t": "And let the peace of God rule in your hearts, to the which also ye are called in one body; and be ye thankful.",
          "r": "Colossians 3:15",
          "v": "KJV"
        },
        {
          "t": "The LORD will give strength unto his people; the LORD will bless his people with peace.",
          "r": "Psalm 29:11",
          "v": "KJV"
        },
        {
          "t": "Be still, and know that I am God.",
          "r": "Psalm 46:10",
          "v": "KJV"
        }
      ]
    },
    {
      "id": "fear",
      "title": "Fear",
      "blurb": "You are never alone",
      "items": [
        {
          "t": "Fear thou not; for I am with thee: be not dismayed; for I am thy God: I will strengthen thee; yea, I will help thee; yea, I will uphold thee with the right hand of my righteousness.",
          "r": "Isaiah 41:10",
          "v": "KJV"
        },
        {
          "t": "For God hath not given us the spirit of fear; but of power, and of love, and of a sound mind.",
          "r": "2 Timothy 1:7",
          "v": "KJV"
        },
        {
          "t": "Have not I commanded thee? Be strong and of a good courage; be not afraid, neither be thou dismayed: for the LORD thy God is with thee whithersoever thou goest.",
          "r": "Joshua 1:9",
          "v": "KJV"
        },
        {
          "t": "Yea, though I walk through the valley of the shadow of death, I will fear no evil: for thou art with me; thy rod and thy staff they comfort me.",
          "r": "Psalm 23:4",
          "v": "KJV"
        },
        {
          "t": "What time I am afraid, I will trust in thee.",
          "r": "Psalm 56:3",
          "v": "KJV"
        },
        {
          "t": "The LORD is my light and my salvation; whom shall I fear? the LORD is the strength of my life; of whom shall I be afraid?",
          "r": "Psalm 27:1",
          "v": "KJV"
        },
        {
          "t": "The LORD is on my side; I will not fear: what can man do unto me?",
          "r": "Psalm 118:6",
          "v": "KJV"
        }
      ]
    }
  ]
};
