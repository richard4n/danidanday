/* ── PARTICLES ── */
const pWrap = document.getElementById('particles');
for (let i = 0; i < 28; i++) {
  const d = document.createElement('div');
  d.className = 'p-dot';
  d.style.left = Math.random() * 100 + '%';
  d.style.top  = (40 + Math.random() * 50) + '%';
  d.style.setProperty('--dur',   (4 + Math.random() * 6) + 's');
  d.style.setProperty('--delay', (Math.random() * 6) + 's');
  pWrap.appendChild(d);
}

/* ── DATA ── */
const SHELL = '';   // only used by the in-Claude editor
const TOK_STATE = '__STATE' + '_JSON__', TOK_SHELL = '__SHELL' + '_JSON__';
const S = window.SITE_DATA;  // from data/content.js
const BIRTH_YEAR = 2007;
const yearLabels = ['Newborns','Year 1','Year 2','Year 3','Year 4','Year 5','Year 6','Year 7','Year 8','Year 9','Year 10','Year 11','Year 12','Year 13','Year 14','Year 15','Year 16','Year 17','Year 18'];
const ICON = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>`;
const esc = t => String(t ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const safeJson = o => JSON.stringify(o).replace(/</g,'\\u003c');
const $ = id => document.getElementById(id);
const KEY = {d:'daniel', q:'daniella', f:'family'};
let editing = false, dirty = false, activeYear = 0, artifactNS = null;
const MAX_DIM = 1200, QUALITY = .74, LIMIT_MB = 15;

/* ── static text ── */
document.querySelectorAll('[data-edit]').forEach(el => { const v = S.texts[el.dataset.edit]; if (v != null) el.textContent = v; });

/* ── slots ── */
function getSlot(id){ const p = id.split(':');
  if (p[0]==='y') return S.years[+p[1]].photos[+p[2]];
  return S[KEY[p[0]]][+p[1]].photo; }
function setSlot(id, v){ const p = id.split(':');
  if (p[0]==='y') S.years[+p[1]].photos[+p[2]] = v;
  else S[KEY[p[0]]][+p[1]].photo = v; }

/* ── render years ── */
const tabsEl = $('yearTabs'), panelsEl = $('yearPanels');
function photoCard(i,k,wide){
  const src = S.years[i].photos[k], id = `y:${i}:${k}`;
  return `<div class="photo-card${wide?' wide':''}" data-slot="${id}">
    ${src ? `<img src="${src}" alt="" loading="lazy">` : `<div class="photo-placeholder">${ICON}<span></span></div>`}
    <div class="slot-tools"><button data-act="up">${src?'Replace':'Upload'}</button>${src?'<button data-act="rm">Remove</button>':''}</div></div>`;
}
const KEEP_FULL_YEAR = 2023;
function visibleYears(){ return S.years.map((y,i) => i).filter(i => editing || S.years[i].photos.some(Boolean)); }
function yearCards(i){
  const full = editing || (BIRTH_YEAR + i) === KEEP_FULL_YEAR;
  if (full) return `<div class="photo-pair">${photoCard(i,0)}${photoCard(i,1)}</div><div class="photo-single">${photoCard(i,2,true)}</div>`;
  const ks = [0,1,2].filter(k => S.years[i].photos[k]);
  if (ks.length === 1) return `<div class="photo-single">${photoCard(i,ks[0],true)}</div>`;
  if (ks.length === 2) return `<div class="photo-pair">${photoCard(i,ks[0])}${photoCard(i,ks[1])}</div>`;
  return `<div class="photo-pair">${photoCard(i,ks[0])}${photoCard(i,ks[1])}</div><div class="photo-single">${photoCard(i,ks[2],true)}</div>`;
}
function renderYears(){
  tabsEl.innerHTML = ''; panelsEl.innerHTML = '';
  const vis = visibleYears();
  if (!vis.includes(activeYear)) activeYear = vis.length ? vis[0] : 0;
  vis.forEach(i => {
    const year = BIRTH_YEAR + i;
    const tab = document.createElement('button');
    tab.className = 'year-tab' + (i===activeYear?' active':''); tab.dataset.i = i; tab.textContent = year;
    tab.onclick = () => { activeYear = i;
      tabsEl.querySelectorAll('.year-tab').forEach(t => t.classList.toggle('active', +t.dataset.i === i));
      panelsEl.querySelectorAll('.year-panel').forEach(p => p.classList.toggle('active', +p.dataset.i === i)); };
    tabsEl.appendChild(tab);
    const panel = document.createElement('div');
    panel.className = 'year-panel' + (i===activeYear?' active':''); panel.dataset.i = i;
    panel.innerHTML = `
      <div class="year-header"><div class="year-num">${year}</div><div class="year-age">${i===0?'Age 0':'Age '+i} &middot; ${yearLabels[i]}</div></div>
      <div class="year-tools ed-only"><button class="ed-btn" data-act="bulk" data-y="${i}">Add several photos at once</button></div>
      ${yearCards(i)}`;
    panelsEl.appendChild(panel);
  });
  afterRender();
}

/* ── render letters ── */
const revObs = new IntersectionObserver(entries => {
  entries.forEach((e,idx) => { if (e.isIntersecting){ setTimeout(() => e.target.classList.add('visible'), idx*60); revObs.unobserve(e.target);} });
}, { threshold: .1 });
function letterCard(w, i, L){
  const id = `${w}:${i}`;
  const badge = w==='f' ? '<span class="twin-dot t1"></span><span class="twin-dot t2"></span>To Daniel &amp; Daniella'
              : w==='d' ? '<span class="twin-dot t1"></span>To Daniel' : '<span class="twin-dot t2"></span>To Daniella';
  const bcls = w==='f' ? 'tb' : w==='d' ? 't1' : 't2';
  const photo = w!=='q' ? '' : `<div class="letter-photo" data-slot="${id}">
      ${L.photo ? `<img src="${L.photo}" alt="" loading="lazy">` : `<div class="letter-photo-placeholder">${ICON}<span></span></div>`}
      <div class="slot-tools"><button data-act="up">${L.photo?'Replace':'Upload'}</button>${L.photo?'<button data-act="rm">Remove</button>':''}</div>
    </div>`;
  return `<div class="letter-card" data-l="${id}" role="button" tabindex="0" aria-expanded="false">${photo}
    <div class="letter-body">
      <div class="letter-num-row"><div class="letter-num">${String(i+1).padStart(2,'0')}</div><div class="letter-to-badge ${bcls}">${badge}</div></div>
      <div class="letter-from" data-lfrom="${id}">${esc(L.author)}</div>
      <div class="letter-hint"></div>
      <div class="letter-reveal"><div class="letter-quote">&#8220;</div><p class="letter-text" data-ltext="${id}">${esc(L.text)}</p></div>
    </div></div>`;
}
function renderLetters(){
  [['f','familyGrid'],['d','danielGrid'],['q','daniellaGrid']].forEach(([w,gid]) => {
    $(gid).innerHTML = S[KEY[w]].map((L,i) => letterCard(w,i,L)).join('');
  });
  document.querySelectorAll('.letter-card').forEach(el => { if (editing) el.classList.add('visible'); else revObs.observe(el); });
  afterRender();
}

/* ── editing plumbing ── */
function editables(){ return document.querySelectorAll('[data-edit],.cap,.letter-text,.letter-from'); }
function applyEditable(){
  editables().forEach(el => {
    if (!editing){ el.removeAttribute('contenteditable'); return; }
    el.setAttribute('contenteditable','plaintext-only');
    if (el.contentEditable !== 'plaintext-only') el.setAttribute('contenteditable','true');
  });
}
function afterRender(){ applyEditable(); updateMeter(); }
function sizeMB(){ return (safeJson(S).length + SHELL.length * 2) / 1048576; }
function updateMeter(){
  const m = sizeMB(), el = $('meter');
  el.textContent = `${m.toFixed(1)} / ${LIMIT_MB} MB used`;
  el.classList.toggle('warn', m > LIMIT_MB * .9);
  $('btn-publish').disabled = !dirty || m > LIMIT_MB;
}
function markDirty(){ dirty = true; updateMeter(); }
let toastT;
function toast(msg){ const t = $('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 3500); }

async function shrink(file){
  const bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
  const sc = Math.min(1, MAX_DIM / Math.max(bmp.width, bmp.height));
  const c = document.createElement('canvas');
  c.width = Math.round(bmp.width*sc); c.height = Math.round(bmp.height*sc);
  const x = c.getContext('2d'); x.fillStyle = '#000'; x.fillRect(0,0,c.width,c.height);
  x.drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL('image/jpeg', QUALITY);
}
function pickFile(input){ return new Promise(res => { input.value = ''; input.onchange = () => res([...input.files]); input.click(); }); }

document.addEventListener('input', e => {
  const el = e.target; if (!editing || !el.closest) return;
  const ed = el.closest('[data-edit]');
  if (ed){ S.texts[ed.dataset.edit] = ed.textContent; return markDirty(); }
  if (el.dataset.cap){ const [i,k] = el.dataset.cap.split(':'); S.years[+i].caps[+k] = el.textContent; return markDirty(); }
  if (el.dataset.ltext){ const [w,i] = el.dataset.ltext.split(':'); S[KEY[w]][+i].text = el.innerText; return markDirty(); }
  if (el.dataset.lfrom){ const [w,i] = el.dataset.lfrom.split(':'); S[KEY[w]][+i].author = el.textContent; return markDirty(); }
});
document.addEventListener('paste', e => {
  if (!editing || !e.target.closest || !e.target.closest('[contenteditable]')) return;
  e.preventDefault();
  document.execCommand('insertText', false, (e.clipboardData || window.clipboardData).getData('text/plain'));
});

document.addEventListener('click', async e => {
  const t = e.target;
  if (t.closest('#edit-bar') || t.closest('#lightbox')) return;
  if (!editing){
    const img = t.closest('.photo-card img, .pl-cover img');
    if (img){ $('lightbox').querySelector('img').src = img.src; $('lightbox').classList.add('open'); }
    return;
  }
  if (t.closest('[contenteditable]')) return;
  const btn = t.closest('[data-act]');
  const act = btn ? btn.dataset.act : null;
  const slotEl = t.closest('[data-slot]');
  try {
    if (act === 'rm'){ setSlot(slotEl.dataset.slot, null); markDirty(); return rerenderAll(); }
    if (act === 'bulk'){
      const i = +btn.dataset.y, files = await pickFile($('fileMulti'));
      if (!files.length) return;
      const empty = [0,1,2].filter(k => !S.years[i].photos[k]);
      const slots = empty.length ? empty : [0,1,2];
      toast('Processing photos…');
      for (let n = 0; n < Math.min(files.length, slots.length); n++) S.years[i].photos[slots[n]] = await shrink(files[n]);
      if (files.length > slots.length) toast(`Only ${slots.length} slots available — extra photos skipped`);
      else toast('Photos added');
      markDirty(); return renderYears();
    }
    if (slotEl && (act === 'up' || !act)){
      const [f] = await pickFile($('file')); if (!f) return;
      toast('Processing photo…');
      setSlot(slotEl.dataset.slot, await shrink(f));
      markDirty(); rerenderAll(); toast('Photo added');
    }
  } catch (err) { console.error(err); toast('Could not read that image. Try a JPG or PNG.'); }
});
function rerenderAll(){ renderYears(); renderLetters(); }
$('lightbox').onclick = () => $('lightbox').classList.remove('open');
addEventListener('keydown', e => { if (e.key === 'Escape') $('lightbox').classList.remove('open'); });

/* ── toolbar ── */
$('btn-toggle').onclick = () => {
  editing = !editing;
  document.body.classList.toggle('editing', editing);
  $('btn-toggle').innerHTML = editing ? '&#10003; Done editing' : '&#9998; Edit site';
  if (editing) document.querySelectorAll('.letter-card').forEach(el => el.classList.add('visible'));
  applyEditable(); updateMeter();
};
$('btn-discard').onclick = () => { if (!dirty || confirm('Discard all unpublished changes?')){ dirty = false; location.reload(); } };
addEventListener('beforeunload', e => { if (dirty){ e.preventDefault(); e.returnValue = ''; } });
$('btn-publish').onclick = async () => {
  if (!artifactNS) return toast('Publishing is not available in this view.');
  const btn = $('btn-publish'); btn.disabled = true; btn.textContent = 'Publishing…';
  try {
    const html = SHELL.replace(TOK_STATE, () => safeJson(S)).replace(TOK_SHELL, () => safeJson(SHELL));
    dirty = false;
    await artifactNS.publish(html);
  } catch (err) {
    dirty = true; btn.textContent = 'Publish changes'; updateMeter();
    const c = err && err.code;
    toast(c==='too_large' ? 'Too many photos — remove a few and try again.' :
          c==='not_writer'||c==='not_granted' ? 'You do not have permission to publish this page.' :
          c==='rate_limited' ? 'Publishing too fast — wait a moment and retry.' :
          c==='conflict' ? 'The page was updated elsewhere; reloading…' : 'Publish failed. Please try again.');
  }
};
(async () => {
  try {
    if (!window.claude) return;
    const [a, u] = await Promise.all([claude.use('artifact'), claude.use('user')]);
    if (!a || !u || !(await u.canEdit())) return;
    artifactNS = a; document.body.classList.add('can-edit');
  } catch (e) {}
})();

renderYears(); renderLetters();

/* ── PLAYLIST + GARDEN ── */
if (S.playlistImg) $('plImg').src = S.playlistImg;
const PASS_HASH = 'e68467f4f8838fc244cddeb8caeb648c12826593a42d9ed4b8257e0ddbe5a229';
let curCat = 0;
const ce = () => editing ? ' contenteditable="true"' : '';
async function sha(t){ const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)); return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2,'0')).join(''); }
function showCat(i){
  curCat = i; const c = S.verses[i];
  document.querySelectorAll('.g-tab').forEach((t,j) => t.classList.toggle('on', j===i));
  $('g-panel').innerHTML = `<div class="g-cat"><h3>${esc(c.title)}</h3><p class="g-blurb" data-vb="${i}"${ce()}>${esc(c.blurb)}</p></div>
    <div class="g-grid">${c.items.map((v,k) => `<figure class="g-card"><button class="g-del" data-vact="del" data-k="${k}" title="Delete verse" type="button">&#10005;</button>
      <blockquote data-vt="${i}:${k}"${ce()}>${esc(v.t)}</blockquote>
      <figcaption><span data-vr="${i}:${k}"${ce()}>${esc(v.r)}</span> &middot; <span data-vv="${i}:${k}"${ce()}>${esc(v.v)}</span></figcaption></figure>`).join('')}
      <div class="g-addcard"><button class="g-add" data-vact="add" type="button">+ Add a verse</button></div></div>`;
}
function buildOpen(){
  const g = $('garden-open');
  g.innerHTML = `<h2 class="g-title">A Garden of Verses</h2>
    <p class="g-sub">For Daniella &mdash; words to hold onto, any day you need them.</p>
    <div class="g-tabs">${S.verses.map((c,i) => `<button class="g-tab" data-cat="${i}" type="button">${esc(c.title)}</button>`).join('')}</div>
    <div id="g-panel"></div><button class="g-lockbtn" id="g-relock" type="button">Close the garden</button>`;
  g.querySelectorAll('.g-tab').forEach(b => b.onclick = () => showCat(+b.dataset.cat));
  $('g-relock').onclick = closeGarden;
  showCat(Math.min(curCat, S.verses.length - 1)); g.hidden = false;
}
function openGarden(){ buildOpen(); $('garden-lock').hidden = true; }
function closeGarden(){
  try{ sessionStorage.removeItem('gardenOpen'); }catch(e){}
  const g = $('garden-open'); g.hidden = true; g.innerHTML = '';
  $('garden-lock').hidden = false; $('g-pass').value = ''; $('g-msg').textContent = '';
}
async function tryGarden(){
  const lock = $('garden-lock'), msg = $('g-msg');
  try {
    if (await sha($('g-pass').value.trim()) === PASS_HASH){
      try{ sessionStorage.setItem('gardenOpen','1'); }catch(e){}
      msg.textContent = ''; openGarden();
    } else {
      msg.textContent = 'Not quite \u2014 think about the riddle';
      lock.classList.remove('shake'); void lock.offsetWidth; lock.classList.add('shake');
    }
  } catch(e){ msg.textContent = 'Your browser could not check the code.'; }
}
$('g-go').onclick = tryGarden;
$('g-pass').addEventListener('keydown', e => { if (e.key === 'Enter') tryGarden(); });
try { if (sessionStorage.getItem('gardenOpen') === '1') openGarden(); } catch(e){}

/* owner editing of verses */
$('btn-toggle').addEventListener('click', () => {
  renderYears();
  if (editing) buildOpen();
  else { let was = false; try{ was = sessionStorage.getItem('gardenOpen') === '1'; }catch(e){}
    if (was) buildOpen(); else { $('garden-open').hidden = true; $('garden-open').innerHTML = ''; } }
});
document.addEventListener('input', e => {
  if (!editing || !e.target.dataset) return;
  const d = e.target.dataset, el = e.target, V = S.verses;
  if (d.vt){ const [c,k] = d.vt.split(':'); V[+c].items[+k].t = el.innerText; }
  else if (d.vr){ const [c,k] = d.vr.split(':'); V[+c].items[+k].r = el.textContent; }
  else if (d.vv){ const [c,k] = d.vv.split(':'); V[+c].items[+k].v = el.textContent; }
  else if (d.vb){ V[+d.vb].blurb = el.textContent; }
  else return;
  markDirty();
});
document.addEventListener('click', e => {
  const b = e.target.closest && e.target.closest('[data-vact]'); if (!b || !editing) return;
  const items = S.verses[curCat].items;
  if (b.dataset.vact === 'del'){ if (confirm('Delete this verse?')){ items.splice(+b.dataset.k, 1); markDirty(); showCat(curCat); } }
  else { items.push({ t: 'Type or paste the verse here', r: 'Book 1:1', v: 'NLT' }); markDirty(); showCat(curCat); }
});


/* ── PHOTO VIEWER ── */
function openViewer(src, capHtml){
  const lb = $('lightbox'); lb.querySelector('img').src = src; lb.querySelector('.lb-cap').innerHTML = capHtml || ''; lb.classList.add('open');
}
document.addEventListener('click', e => {
  if (editing || !e.target.closest) return;
  const t = e.target;
  const lp = t.closest('.letter-photo'), pc = t.closest('.photo-card'), cv = t.closest('.pl-cover');
  const box = lp || pc || cv; if (!box) return;
  const img = box.querySelector('img'); if (!img) return;
  let cap = '';
  if (lp){ cap = ''; }
  else if (pc){ cap = ''; }
  openViewer(img.src, cap);
});
$('lightbox').onclick = e => { if (!e.target.closest('.lb-cap')) $('lightbox').classList.remove('open'); };
$('lb-close').onclick = () => $('lightbox').classList.remove('open');


/* ── SMART PHOTO FIT ── */
function fitFrames(){
  document.querySelectorAll('.photo-card img, .letter-photo img').forEach(img => {
    const apply = () => {
      const f = img.parentElement; if (!img.naturalWidth) return;
      const fr = f.classList.contains('wide') ? 16/9 : 4/3, ir = img.naturalWidth / img.naturalHeight;
      const contain = Math.abs(Math.log(ir / fr)) > Math.log(1.25);
      f.classList.toggle('fit-contain', contain);
      if (contain) f.style.setProperty('--bg', `url("${img.src}")`); else f.style.removeProperty('--bg');
    };
    if (img.complete) apply(); else img.addEventListener('load', apply, { once: true });
  });
}
const _afterRender = afterRender;
afterRender = function(){ _afterRender(); fitFrames(); };
fitFrames();

/* click-to-read messages */
function toggleCard(card){ const o = card.classList.toggle('open'); card.setAttribute('aria-expanded', o); }
document.addEventListener('click', e => {
  if (editing || !e.target.closest) return;
  const card = e.target.closest('.letter-card');
  if (!card || e.target.closest('.letter-reveal')) return;
  const ph = e.target.closest('.letter-photo'); if (ph && ph.querySelector('img')) return;
  toggleCard(card);
});
document.addEventListener('keydown', e => {
  if (editing || !e.target.classList || !e.target.classList.contains('letter-card')) return;
  if (e.key === 'Enter' || e.key === ' '){ e.preventDefault(); toggleCard(e.target); }
});

/* ── CONFETTI ── */
const canvas = document.getElementById('confetti-canvas');
const ctx    = canvas.getContext('2d');
let pieces = [], animating = false;
const cols = ['#C9A84C','#F0D080','#E8C4B0','#C87A6E','#FAF6EE','#D4A76A','#fff'];
function resize() { canvas.width = innerWidth; canvas.height = innerHeight; }
function Piece(x,y) {
  this.x=x;this.y=y;this.sz=Math.random()*9+4;
  this.color=cols[Math.floor(Math.random()*cols.length)];
  this.rot=Math.random()*Math.PI*2;
  this.vx=(Math.random()-.5)*7;this.vy=Math.random()*-13-5;
  this.va=(Math.random()-.5)*.22;this.g=.38;
  this.shape=Math.random()>.4?'rect':'circle';this.opacity=1;
}
Piece.prototype.update=function(){this.vy+=this.g;this.x+=this.vx;this.y+=this.vy;this.rot+=this.va;if(this.y>canvas.height)this.opacity=0;};
Piece.prototype.draw=function(){ctx.save();ctx.translate(this.x,this.y);ctx.rotate(this.rot);ctx.globalAlpha=this.opacity;ctx.fillStyle=this.color;if(this.shape==='rect')ctx.fillRect(-this.sz/2,-this.sz/4,this.sz,this.sz*.45);else{ctx.beginPath();ctx.arc(0,0,this.sz/2,0,Math.PI*2);ctx.fill();}ctx.restore();};
function loop(){if(!animating)return;ctx.clearRect(0,0,canvas.width,canvas.height);pieces=pieces.filter(p=>p.opacity>0);pieces.forEach(p=>{p.update();p.draw();});if(pieces.length>0)requestAnimationFrame(loop);else animating=false;}
function launchConfetti(){
  if(!animating){animating=true;loop();}
  const cx=canvas.width/2,cy=canvas.height*.65;
  for(let i=0;i<240;i++) setTimeout(()=>pieces.push(new Piece(cx+(Math.random()-.5)*120,cy)),i*4);
}
addEventListener('resize',resize);resize();
addEventListener('load',()=>setTimeout(launchConfetti,700));
