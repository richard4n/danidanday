# Birthday Website — Daniel & Daniella

A static website built with **plain HTML, CSS and vanilla JavaScript**. There is no framework,
no build step and nothing to install, so it can be hosted exactly as it is.

## Deploy to GitHub Pages (about 3 minutes)

1. Create a new repository on GitHub (for example `birthday-website`). Public is simplest; private
   repositories need a paid plan to use Pages.
2. Upload everything from this folder to the repository root (`index.html` must be at the top level):
   - **Easiest:** on the new repo's page click **uploading an existing file**, drag in the *contents*
     of this folder (including the `assets` and `data` folders and the hidden `.nojekyll` file), then **Commit changes**.
   - **Or with git:**
     ```bash
     git remote add origin https://github.com/YOUR-USERNAME/birthday-website.git
     git push -u origin main
     ```
     (this folder is already a git repository with one commit)
3. In the repository go to **Settings → Pages**. Under **Build and deployment**, set
   **Source: Deploy from a branch**, **Branch: `main`**, **Folder: `/ (root)`**, then **Save**.
4. Wait a minute or two. Your site will be at:
   `https://YOUR-USERNAME.github.io/birthday-website/`

### About the base path
All links in the project are **relative** (`styles.css`, `data/content.js`, `assets/...`), so it works
from a repository subfolder (`/birthday-website/`) *and* from a root/custom domain with no changes.
You do not need to set any base path.

## Run it locally

Open `index.html` in a browser, or serve the folder: `python3 -m http.server` then visit http://localhost:8000.

## What's in the project

```
index.html          Page structure (hero, year-by-year, family letters, individual letters,
                    playlist + QR code, password-protected verse garden, closing)
styles.css          All styling
script.js           All behaviour (year tabs, click-to-read messages, photo viewer, verse garden, password gate)
data/content.js     ALL editable content: headings, messages, sender names, verses, photo paths
assets/
  playlist-cover.jpg
  photos/years/     Year-by-year photos, named YEAR-SLOT.jpg (slot 1–3)
  photos/daniella/  Sender photos for Daniella's 15 messages
.nojekyll           Tells GitHub Pages to serve the files as-is
```

## Changing content later

- **Messages, names, verses, headings:** edit `data/content.js`.
  - `family` – 4 messages to both; `daniel` / `daniella` – 15 messages each (`text`, `author`, `photo`)
  - `verses` – sections with `items` of `{ t: text, r: reference, v: translation }`
  - `years` – `photos` is `[slot1, slot2, slot3]` (`null` = empty). Years with no photos are hidden;
    years with 1–2 photos show only those (2023 keeps its three slots — see `KEEP_FULL_YEAR` in `script.js`).
- **Photos:** add a JPG under `assets/photos/...` and reference its path in `data/content.js`.
  Keep images about 1200px wide so the page loads fast. File names are **case-sensitive** on GitHub Pages.
- **Playlist QR code / link:** the QR is an inline SVG in `index.html` (search for `qr-card`) and the
  "Open in Spotify" link sits next to it. To change the playlist, generate a new QR code and replace both.
- **Secret code for the verse garden:** `PASS_HASH` in `script.js` is the SHA-256 hash of the code.
  Create a new one with `echo -n "NEWCODE" | shasum -a 256` and paste the hash. The riddle is the
  `gRiddle` text in `index.html` (or `texts.gRiddle` in `data/content.js`).

## Good to know

- **External resources:** Google Fonts (Cormorant Garamond, DM Sans, Great Vibes, Dancing Script) and
  the Spotify playlist link. Without internet the fonts fall back to system fonts.
- **The password is a gate, not real security.** The verses are in the page source, so anyone
  technical could read them. Keep anything private out of it. The secret-code check needs HTTPS or
  localhost (GitHub Pages is HTTPS).
- **The "Edit site" toolbar is not part of the exported site.** It only works on the Claude-hosted
  version (it publishes through Claude), so it stays hidden here. Edit `data/content.js` instead.
  `script.js` contains a small, harmless block that checks for Claude and does nothing elsewhere.
- **Bible text** is the King James Version (public domain). NLT is copyrighted and not bundled; add
  your own NLT verses with `v: "NLT"`.
- Photo sizes: the whole repo is about 5 MB, well within GitHub's limits.
